Material CalendarView Sample App
================================

The sample app contains a mixture of implementations to help test and debug during development,
and to help new users understand how to implement some functionality.